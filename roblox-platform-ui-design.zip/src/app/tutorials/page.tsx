import ComingSoon from "@/components/ComingSoon";

export default function TutorialsPage() {
  return <ComingSoon title="الشروحات" />;
}

import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "عرب هاك | CCRAFT SPACE - منصة سكربتات ROBLOX العربية",
  description: "منصة عربية متكاملة لسكربتات ROBLOX، أدوات المطورين، المساعد الذكي NOVA AI، ومفتاح دلتا.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-[#0a0a0f] text-slate-50 antialiased">{children}</body>
    </html>
  );
}

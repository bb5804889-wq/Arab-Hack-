import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

const KEYS = ["aiApiKey", "scriptApiUrl", "deltaApiUrl"];

export async function GET() {
  try {
    const rows = await db.select().from(settings).where(eq(settings.key, "aiApiKey"));
    const all = await db.select().from(settings);
    const map: Record<string, string> = {};
    for (const row of all) {
      if (KEYS.includes(row.key)) {
        map[row.key] = row.value;
      }
    }
    return NextResponse.json(map);
  } catch (error) {
    console.error("Settings GET error:", error);
    return NextResponse.json({});
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    for (const key of KEYS) {
      const value = typeof body[key] === "string" ? body[key] : "";
      const existing = await db.select().from(settings).where(eq(settings.key, key));
      if (existing.length > 0) {
        await db
          .update(settings)
          .set({ value, updatedAt: new Date() })
          .where(eq(settings.key, key));
      } else {
        await db.insert(settings).values({ key, value });
      }
    }
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Settings POST error:", error);
    return NextResponse.json({ success: false }, { status: 500 });
  }
}

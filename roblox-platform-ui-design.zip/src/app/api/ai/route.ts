import { NextRequest, NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const { message, codeMode, history } = await req.json();

    // Read stored API key
    let apiKey = "";
    try {
      const row = await db.select().from(settings).where(eq(settings.key, "aiApiKey"));
      apiKey = row[0]?.value || "";
    } catch {
      apiKey = "";
    }

    const systemPrompt = codeMode
      ? "أنت NOVA AI، مساعد برمجة متخصص في سكربتات ROBLOX وLua. أجب بالعربية مع أكواد واضحة ومعلقة."
      : "أنت NOVA AI، مساعد عربي متخصص في سكربتات ROBLOX والألعاب. أجب بالعربية بشكل مختصر ومفيد.";

    if (!apiKey) {
      // Demo fallback response
      let reply = "";
      if (codeMode) {
        reply = `إليك مثال على سكربت بسيط:\n\n\`\`\`lua\n-- NOVA AI Script\nprint("Hello from NOVA!")\n\`\`\`\n\nملاحظة: لم يتم تعيين مفتاح Gemini في إعدادات API.`;
      } else {
        reply = `مرحباً! أنا NOVA AI. يمكنني مساعدتك في سكربتات ROBLOX والأكواد.\n\nلاحظ: لم يتم تعيين مفتاح Gemini بعد. اذهب إلى إعدادات API لإضافته.`;
      }
      return NextResponse.json({ reply });
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const chat = model.startChat({
      history: [
        { role: "user", parts: [{ text: systemPrompt }] },
        { role: "model", parts: [{ text: "حسناً، أنا جاهز للمساعدة." }] },
        ...(Array.isArray(history) ? history.map((h: { role: string; content: string }) => ({
          role: h.role === "user" ? "user" : "model",
          parts: [{ text: h.content }],
        })) : []),
      ],
    });

    const result = await chat.sendMessage(message);
    const reply = result.response.text();

    return NextResponse.json({ reply });
  } catch (error) {
    console.error("AI error:", error);
    return NextResponse.json(
      { reply: "عذراً، حدث خطأ في الاتصال بـ NOVA AI. تأكد من صحة مفتاح API." },
      { status: 500 }
    );
  }
}

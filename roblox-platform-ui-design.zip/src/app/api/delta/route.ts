import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

function generateKey(platform: string) {
  const prefix = "AH";
  const platformCode = platform.slice(0, 3).toUpperCase();
  const random = Math.random().toString(36).substring(2, 10).toUpperCase();
  const timestamp = Date.now().toString(36).toUpperCase();
  return `${prefix}-${platformCode}-${random}-${timestamp}`;
}

export async function POST(req: NextRequest) {
  try {
    const { platform, sourceUrl } = await req.json();

    let apiUrl = "";
    try {
      const row = await db.select().from(settings).where(eq(settings.key, "deltaApiUrl"));
      apiUrl = row[0]?.value || "";
    } catch {
      apiUrl = "";
    }

    const target = sourceUrl || apiUrl;

    if (target) {
      try {
        const res = await fetch(target, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ platform }),
        });
        if (res.ok) {
          const data = await res.json();
          return NextResponse.json({
            key: data.key || generateKey(platform),
            version: data.version || `v2.6-${platform}`,
            source: "external",
          });
        }
      } catch (error) {
        console.error("Delta API fetch error:", error);
      }
    }

    // Demo fallback
    return NextResponse.json({
      key: generateKey(platform),
      version: `v2.6-${platform}`,
      source: "generated",
    });
  } catch (error) {
    console.error("Delta route error:", error);
    return NextResponse.json(
      { key: "AH-DELTA-ERROR", version: "unknown", source: "error" },
      { status: 500 }
    );
  }
}

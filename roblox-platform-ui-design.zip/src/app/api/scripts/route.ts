import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

const demoScripts = [
  { id: 1, name: "Infinite Yield", game: "Universal", description: "أداة تحكم كاملة", likes: 4520 },
  { id: 2, name: "Blox Fruits Auto Farm", game: "Blox Fruits", description: "تجميع تلقائي", likes: 3890 },
  { id: 3, name: "King Legacy GUI", game: "King Legacy", description: "واجهة تحكم متكاملة", likes: 2100 },
  { id: 4, name: "Murder Mystery 2 ESP", game: "MM2", description: "رؤية اللاعبين", likes: 1760 },
  { id: 5, name: "Adopt Me Auto Pet", game: "Adopt Me", description: "عناية تلقائية بالحيوانات", likes: 1340 },
];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q") || "";

  let apiUrl = "";
  try {
    const row = await db.select().from(settings).where(eq(settings.key, "scriptApiUrl"));
    apiUrl = row[0]?.value || "";
  } catch {
    apiUrl = "";
  }

  if (apiUrl) {
    try {
      const res = await fetch(`${apiUrl}?q=${encodeURIComponent(q)}`, { next: { revalidate: 60 } });
      if (res.ok) {
        const data = await res.json();
        return NextResponse.json(data);
      }
    } catch (error) {
      console.error("Script API fetch error:", error);
    }
  }

  // Fallback demo data
  const filtered = demoScripts.filter(
    (s) =>
      s.name.toLowerCase().includes(q.toLowerCase()) ||
      s.game.toLowerCase().includes(q.toLowerCase())
  );

  return NextResponse.json({ scripts: filtered, source: apiUrl ? "external" : "demo" });
}

"use client";

import { useEffect, useState } from "react";
import { Key, Save, Lock, ArrowRight, Globe, Sparkles, Code2, Zap } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

const CORRECT_PASSWORD = "AH-7392-XQ";

export default function ApiSettingsPage() {
  const [password, setPassword] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState("");
  const [aiApiKey, setAiApiKey] = useState("");
  const [scriptApiUrl, setScriptApiUrl] = useState("");
  const [deltaApiUrl, setDeltaApiUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (unlocked) {
      fetch("/api/settings")
        .then((r) => r.json())
        .then((data) => {
          setAiApiKey(data.aiApiKey || "");
          setScriptApiUrl(data.scriptApiUrl || "");
          setDeltaApiUrl(data.deltaApiUrl || "");
        })
        .catch(() => null);
    }
  }, [unlocked]);

  function unlock() {
    if (password === CORRECT_PASSWORD) {
      setUnlocked(true);
      setError("");
    } else {
      setError("كلمة السر غير صحيحة");
    }
  }

  async function saveSettings() {
    setSaving(true);
    setSaved(false);
    try {
      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ aiApiKey, scriptApiUrl, deltaApiUrl }),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch {
      setError("فشل الحفظ");
    } finally {
      setSaving(false);
    }
  }

  if (!unlocked) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-[#0a0a0f] px-4">
        <Link
          href="/"
          className="absolute top-4 right-4 flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white"
        >
          <ArrowRight className="h-5 w-5" />
        </Link>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md rounded-3xl border border-white/10 bg-[#13131f] p-8 text-center"
        >
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-violet-600/20 text-violet-300">
            <Lock className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-black text-white">إعدادات API</h1>
          <p className="mt-2 text-sm text-slate-400">
            هذه المنطقة محمية. أدخل كلمة السر للمتابعة.
          </p>

          <div className="mt-6 space-y-3">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && unlock()}
              placeholder="كلمة السر"
              className="w-full rounded-xl border border-white/10 bg-[#0a0a0f] px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-violet-500/50 focus:outline-none"
            />
            {error && <p className="text-xs text-red-400">{error}</p>}
            <button
              onClick={unlock}
              className="w-full rounded-xl btn-gradient py-3 text-sm font-bold text-white shadow-lg shadow-violet-900/30 transition hover:brightness-110"
            >
              فتح
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] px-4 py-6">
      <div className="mx-auto max-w-3xl">
        <div className="mb-6 flex items-center justify-between">
          <Link
            href="/"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-black text-white">إعدادات API الموقع</h1>
          <div className="h-10 w-10" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="rounded-2xl border border-white/10 bg-[#13131f] p-5">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-pink-500/20 text-pink-300">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-bold text-white">NOVA AI API</h2>
                <p className="text-xs text-slate-500">مفتاح Gemini / Google AI</p>
              </div>
            </div>
            <input
              value={aiApiKey}
              onChange={(e) => setAiApiKey(e.target.value)}
              placeholder="مثال: AIzaSy..."
              className="w-full rounded-xl border border-white/10 bg-[#0a0a0f] px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-pink-500/50 focus:outline-none"
            />
          </div>

          <div className="rounded-2xl border border-white/10 bg-[#13131f] p-5">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-500/20 text-blue-300">
                <Globe className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-bold text-white">مصدر السكربتات</h2>
                <p className="text-xs text-slate-500">رابط API لجلب السكربتات من الإنترنت</p>
              </div>
            </div>
            <input
              value={scriptApiUrl}
              onChange={(e) => setScriptApiUrl(e.target.value)}
              placeholder="https://api.example.com/scripts"
              className="w-full rounded-xl border border-white/10 bg-[#0a0a0f] px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-blue-500/50 focus:outline-none"
            />
          </div>

          <div className="rounded-2xl border border-white/10 bg-[#13131f] p-5">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-yellow-500/20 text-yellow-300">
                <Zap className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-bold text-white">Delta Key API</h2>
                <p className="text-xs text-slate-500">الموقع المصدر لمفاتيح دلتا</p>
              </div>
            </div>
            <input
              value={deltaApiUrl}
              onChange={(e) => setDeltaApiUrl(e.target.value)}
              placeholder="https://gateway.platoboost.com/..."
              className="w-full rounded-xl border border-white/10 bg-[#0a0a0f] px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-yellow-500/50 focus:outline-none"
            />
          </div>

          <button
            onClick={saveSettings}
            disabled={saving}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 py-3 text-sm font-bold text-white shadow-lg shadow-violet-900/30 transition hover:brightness-110 disabled:opacity-50"
          >
            {saving ? (
              "جاري الحفظ..."
            ) : (
              <>
                <Save className="h-4 w-4" />
                حفظ الإعدادات
              </>
            )}
          </button>

          {saved && (
            <p className="text-center text-sm text-emerald-400">تم حفظ الإعدادات بنجاح</p>
          )}

          <div className="rounded-2xl border border-white/5 bg-white/[0.03] p-4 text-center">
            <p className="text-xs text-slate-500">
              الـ API المُعد هنا يعمل على كل الموقع: الذكاء الاصطناعي، البحث عن السكربتات، وتوليد مفاتيح دلتا.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

import ComingSoon from "@/components/ComingSoon";

export default function UploadPage() {
  return <ComingSoon title="نشر سكربت" />;
}

"use client";

import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  Mic,
  Send,
  Code2,
  FileText,
  ExternalLink,
  Sparkles,
  Wifi,
  MoreHorizontal,
} from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const tabs = [
  "لعبة تجنب عقبات",
  "عالم فضائي",
  "سكربت جافاسكريبت",
  "فيديوهات",
];

const fileCard = {
  name: "README.md",
  size: "2.4 KB",
  preview: "# Delta Exploit API\n## Setup\n1. Install dependencies...",
};

export default function NovaPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "مرحباً! أنا NOVA AI، مساعدك الذكي في عالم سكربتات ROBLOX. كيف يمكنني مساعدتك اليوم؟",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [codeMode, setCodeMode] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function sendMessage() {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput("");
    setMessages((m) => [...m, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg,
          codeMode,
          history: messages,
        }),
      });
      const data = await res.json();
      setMessages((m) => [
        ...m,
        { role: "assistant", content: data.reply || "عذراً، حدث خطأ." },
      ]);
    } catch {
      setMessages((m) => [
        ...m,
        { role: "assistant", content: "تعذر الاتصال بـ NOVA AI. حاول لاحقاً." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex h-screen flex-col bg-[#0a0a0f]">
      {/* Top bar */}
      <div className="flex items-center justify-between border-b border-white/10 bg-[#13131f]/90 px-4 py-3 backdrop-blur">
        <Link
          href="/"
          className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white"
        >
          <ArrowRight className="h-5 w-5" />
        </Link>

        <div className="flex flex-col items-center">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-pink-400" />
            <span className="text-base font-black text-white">NOVA AI</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-slate-400">
            <span className="flex items-center gap-1 text-emerald-400">
              <Wifi className="h-3 w-3" />
              متصل
            </span>
            <span>•</span>
            <span>gemini-3.5-flash-lite</span>
          </div>
        </div>

        <button className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white">
          <MoreHorizontal className="h-5 w-5" />
        </button>
      </div>

      {/* Code mode toggle */}
      <div className="flex items-center justify-between border-b border-white/5 bg-[#13131f]/50 px-4 py-2">
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {tabs.map((tab, i) => (
            <button
              key={tab}
              onClick={() => setActiveTab(i)}
              className={`whitespace-nowrap rounded-full px-3 py-1 text-[11px] font-medium transition ${
                activeTab === i
                  ? "bg-violet-600/30 text-violet-200"
                  : "bg-white/5 text-slate-400 hover:text-white"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        <button
          onClick={() => setCodeMode((v) => !v)}
          className={`ml-2 flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-bold transition ${
            codeMode
              ? "bg-yellow-500/20 text-yellow-300"
              : "bg-white/5 text-slate-400"
          }`}
        >
          <Code2 className="h-3 w-3" />
          وضع الأكواد
        </button>
      </div>

      {/* Chat area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 scrollbar-thin">
        <div className="mx-auto max-w-3xl space-y-4">
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === "user" ? "justify-start" : "justify-end"}`}
            >
              <div
                className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "rounded-tr-sm bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white"
                    : "rounded-tl-sm bg-[#1f1f2e] text-slate-200"
                }`}
              >
                {msg.content}
              </div>
            </motion.div>
          ))}

          {loading && (
            <div className="flex justify-end">
              <div className="rounded-2xl rounded-tl-sm bg-[#1f1f2e] px-4 py-3">
                <div className="flex gap-1">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-violet-400" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-violet-400 [animation-delay:0.1s]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-violet-400 [animation-delay:0.2s]" />
                </div>
              </div>
            </div>
          )}

          {/* Attached file card */}
          <div className="flex justify-end">
            <div className="max-w-sm rounded-2xl border border-white/10 bg-[#1a1a2e] p-3">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-500/20 text-blue-300">
                  <FileText className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <p className="text-xs font-bold text-white">{fileCard.name}</p>
                  <p className="text-[10px] text-slate-500">{fileCard.size}</p>
                </div>
                <button className="flex items-center gap-1 rounded-lg bg-white/5 px-2 py-1 text-[10px] text-slate-300 transition hover:bg-white/10">
                  فتح الملف
                  <ExternalLink className="h-3 w-3" />
                </button>
              </div>
              <p className="mt-2 text-[10px] text-slate-500 line-clamp-2">{fileCard.preview}</p>
            </div>
          </div>

          <div ref={bottomRef} />
        </div>
      </div>

      {/* Input bar */}
      <div className="border-t border-white/10 bg-[#13131f]/95 p-3 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center gap-2 rounded-2xl border border-white/10 bg-[#0f0f18] px-3 py-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder="اكتب لـ Nova..."
            className="flex-1 bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none"
          />
          <button className="flex h-8 w-8 items-center justify-center rounded-full text-slate-400 transition hover:bg-white/10 hover:text-white">
            <Mic className="h-4 w-4" />
          </button>
          <button
            onClick={sendMessage}
            disabled={loading || !input.trim()}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-violet-600 to-blue-600 text-white shadow-lg shadow-violet-900/30 transition hover:brightness-110 disabled:opacity-50"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}

import ComingSoon from "@/components/ComingSoon";

export default function UploadTutorialPage() {
  return <ComingSoon title="نشر شرح" />;
}

import ComingSoon from "@/components/ComingSoon";

export default function ApkPage() {
  return <ComingSoon title="تطبيقات APK" />;
}

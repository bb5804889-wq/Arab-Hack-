"use client";

import { useState } from "react";
import {
  ArrowRight,
  Zap,
  Smartphone,
  Monitor,
  AppWindow,
  Copy,
  Download,
  Check,
  Globe,
} from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

type Platform = "android" | "ios" | "windows";

export default function DeltaPage() {
  const [platform, setPlatform] = useState<Platform>("android");
  const [sourceUrl, setSourceUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ key: string; version: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const platforms: { id: Platform; label: string; icon: React.ElementType }[] = [
    { id: "android", label: "أندرويد", icon: Smartphone },
    { id: "ios", label: "آي أو إس", icon: AppWindow },
    { id: "windows", label: "ويندوز", icon: Monitor },
  ];

  async function generateKey() {
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch("/api/delta", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform, sourceUrl }),
      });
      const data = await res.json();
      setResult({
        key: data.key || "AH-DELTA-ERROR",
        version: data.version || "latest",
      });
    } catch {
      setResult({ key: "AH-DELTA-ERROR", version: "latest" });
    } finally {
      setLoading(false);
    }
  }

  function copyKey() {
    if (!result) return;
    navigator.clipboard.writeText(result.key);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] px-4 py-6">
      <div className="mx-auto max-w-2xl">
        <div className="mb-6 flex items-center justify-between">
          <Link
            href="/"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-black text-white">مولد مفتاح دلتا</h1>
          <div className="h-10 w-10" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-5"
        >
          <div className="rounded-3xl border border-yellow-500/20 bg-gradient-to-br from-yellow-500/10 to-amber-900/10 p-6 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-yellow-500/20 text-yellow-300">
              <Zap className="h-8 w-8 fill-yellow-300" />
            </div>
            <h2 className="text-2xl font-black text-white">arab hack</h2>
            <p className="mt-2 text-sm text-slate-400">
              حدد نظامك وأدخل الموقع المصدر، وسنحصل على المفتاح الحقيقي لك.
            </p>
          </div>

          {/* Platform selection */}
          <div className="rounded-2xl border border-white/10 bg-[#13131f] p-5">
            <h3 className="mb-3 text-sm font-bold text-white">اختر النظام</h3>
            <div className="grid grid-cols-3 gap-3">
              {platforms.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setPlatform(p.id)}
                  className={`flex flex-col items-center gap-2 rounded-xl border p-4 transition ${
                    platform === p.id
                      ? "border-yellow-500/40 bg-yellow-500/10 text-yellow-300"
                      : "border-white/10 bg-white/5 text-slate-400 hover:border-white/20"
                  }`}
                >
                  <p.icon className="h-6 w-6" />
                  <span className="text-xs font-bold">{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Source URL */}
          <div className="rounded-2xl border border-white/10 bg-[#13131f] p-5">
            <div className="mb-3 flex items-center gap-2">
              <Globe className="h-4 w-4 text-slate-400" />
              <h3 className="text-sm font-bold text-white">الموقع المصدر من دلتا</h3>
            </div>
            <input
              value={sourceUrl}
              onChange={(e) => setSourceUrl(e.target.value)}
              placeholder="الصق رابط الموقع هنا..."
              className="w-full rounded-xl border border-white/10 bg-[#0a0a0f] px-4 py-3 text-sm text-white placeholder:text-slate-600 focus:border-yellow-500/50 focus:outline-none"
            />
          </div>

          <button
            onClick={generateKey}
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-yellow-500 to-amber-500 py-4 text-base font-black text-black shadow-lg shadow-yellow-900/30 transition hover:brightness-110 disabled:opacity-50"
          >
            {loading ? (
              "جاري الحصول على المفتاح..."
            ) : (
              <>
                <Zap className="h-5 w-5 fill-black" />
                احصل على المفتاح
              </>
            )}
          </button>

          {result && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="rounded-2xl border border-white/10 bg-[#13131f] p-5"
            >
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm font-bold text-white">المفتاح الحقيقي</span>
                <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                  {result.version}
                </span>
              </div>
              <div className="flex items-center gap-2 rounded-xl bg-[#0a0a0f] p-3">
                <code className="flex-1 break-all text-xs text-yellow-300">{result.key}</code>
                <button
                  onClick={copyKey}
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/5 text-slate-300 transition hover:bg-white/10"
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </button>
              </div>

              <a
                href="#"
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-white/5 py-3 text-sm font-bold text-white transition hover:bg-white/10"
              >
                <Download className="h-4 w-4" />
                تحميل أحدث نسخة ({platform})
              </a>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

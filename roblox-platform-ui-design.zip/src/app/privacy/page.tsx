import ComingSoon from "@/components/ComingSoon";

export default function PrivacyPage() {
  return <ComingSoon title="الخصوصية" />;
}

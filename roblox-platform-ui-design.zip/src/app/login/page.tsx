import ComingSoon from "@/components/ComingSoon";

export default function LoginPage() {
  return <ComingSoon title="تسجيل الدخول" />;
}

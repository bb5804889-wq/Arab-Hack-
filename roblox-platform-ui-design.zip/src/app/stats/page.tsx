"use client";

import { ArrowRight, Users, FileCode, Download, Zap, Activity } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

const stats = [
  { label: "السكربتات", value: "12,430", icon: FileCode, color: "text-violet-300" },
  { label: "المستخدمين", value: "89,210", icon: Users, color: "text-blue-300" },
  { label: "التحميلات", value: "345,100", icon: Download, color: "text-emerald-300" },
  { label: "مفاتيح دلتا", value: "45,900", icon: Zap, color: "text-yellow-300" },
];

export default function StatsPage() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] px-4 py-6">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex items-center justify-between">
          <Link
            href="/"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-black text-white">الإحصائيات المباشرة</h1>
          <div className="h-10 w-10" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 gap-4 sm:grid-cols-2"
        >
          {stats.map((s, i) => (
            <div
              key={s.label}
              className="rounded-2xl border border-white/10 bg-[#13131f] p-6 transition hover:border-violet-500/30"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">{s.label}</p>
                  <p className="mt-1 text-3xl font-black text-white">{s.value}</p>
                </div>
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-white/5 ${s.color}`}>
                  <s.icon className="h-6 w-6" />
                </div>
              </div>
            </div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-5 rounded-2xl border border-white/10 bg-[#13131f] p-6"
        >
          <div className="mb-4 flex items-center gap-2">
            <Activity className="h-5 w-5 text-violet-400" />
            <h2 className="font-bold text-white">النشاط الحي</h2>
          </div>
          <div className="space-y-3">
            {[1, 2, 3].map((_, i) => (
              <div key={i} className="flex items-center gap-3 rounded-xl bg-white/5 p-3">
                <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                <p className="text-sm text-slate-300">مستخدم جديد انضم للمنصة</p>
                <span className="mr-auto text-[10px] text-slate-500">الآن</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}

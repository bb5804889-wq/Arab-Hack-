import ComingSoon from "@/components/ComingSoon";

export default function EditorPage() {
  return <ComingSoon title="محرر الأكواد" />;
}

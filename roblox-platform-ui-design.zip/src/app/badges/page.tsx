import ComingSoon from "@/components/ComingSoon";

export default function BadgesPage() {
  return <ComingSoon title="البادجات" />;
}

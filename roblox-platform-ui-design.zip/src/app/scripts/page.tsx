"use client";

import { useEffect, useState } from "react";
import { ArrowRight, FileCode, Search, Heart, ExternalLink } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

interface Script {
  id: number;
  name: string;
  game: string;
  description: string;
  likes: number;
}

export default function ScriptsPage() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  useEffect(() => {
    fetch("/api/scripts")
      .then((r) => r.json())
      .then((data) => {
        setScripts(data.scripts || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filtered = scripts.filter(
    (s) =>
      s.name.toLowerCase().includes(q.toLowerCase()) ||
      s.game.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0a0a0f] px-4 py-6">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex items-center justify-between">
          <Link
            href="/"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-black text-white">السكربتات</h1>
          <div className="h-10 w-10" />
        </div>

        <div className="mb-5 flex items-center gap-2 rounded-2xl border border-white/10 bg-[#13131f] px-4 py-3">
          <Search className="h-5 w-5 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث عن سكربت أو لعبة..."
            className="flex-1 bg-transparent text-sm text-white placeholder:text-slate-600 focus:outline-none"
          />
        </div>

        {loading ? (
          <div className="py-20 text-center text-slate-500">جاري التحميل...</div>
        ) : filtered.length === 0 ? (
          <div className="py-20 text-center text-slate-500">لا توجد نتائج</div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {filtered.map((s, i) => (
              <motion.div
                key={s.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-white/10 bg-[#13131f] p-5 transition hover:border-violet-500/30"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/20 text-violet-300">
                      <FileCode className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white">{s.name}</h3>
                      <p className="text-xs text-slate-500">{s.game}</p>
                    </div>
                  </div>
                  <button className="flex items-center gap-1 text-xs text-slate-400 hover:text-pink-400">
                    <Heart className="h-4 w-4" />
                    {s.likes}
                  </button>
                </div>
                <p className="mt-3 text-sm text-slate-400">{s.description}</p>
                <button className="mt-4 flex items-center gap-1 text-xs font-bold text-violet-300 hover:text-violet-200">
                  عرض السكربت
                  <ExternalLink className="h-3 w-3" />
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

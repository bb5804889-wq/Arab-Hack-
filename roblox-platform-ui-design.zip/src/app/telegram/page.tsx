import ComingSoon from "@/components/ComingSoon";

export default function TelegramPage() {
  return <ComingSoon title="تلجرام" />;
}

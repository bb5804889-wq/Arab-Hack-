import TopBar from "@/components/TopBar";
import HeroSection from "@/components/HeroSection";
import GridCategories from "@/components/GridCategories";
import CardsSection from "@/components/CardsSection";
import Footer from "@/components/Footer";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#0a0a0f]">
      <TopBar />
      <HeroSection />
      <GridCategories />
      <CardsSection />
      <Footer />
    </main>
  );
}

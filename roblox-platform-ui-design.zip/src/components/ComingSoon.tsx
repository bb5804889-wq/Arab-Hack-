"use client";

import { ArrowRight, Construction } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function ComingSoon({ title }: { title: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#0a0a0f] px-4">
      <Link
        href="/"
        className="absolute top-4 right-4 flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-slate-400 transition hover:text-white"
      >
        <ArrowRight className="h-5 w-5" />
      </Link>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-violet-600/20 text-violet-300">
          <Construction className="h-10 w-10" />
        </div>
        <h1 className="text-3xl font-black text-white">{title}</h1>
        <p className="mt-3 text-slate-400">قريباً في عرب هاك</p>
      </motion.div>
    </div>
  );
}

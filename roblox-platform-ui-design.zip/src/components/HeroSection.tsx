"use client";

import { Zap, BarChart3 } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden px-4 pt-28 pb-10">
      {/* Background glows */}
      <div className="pointer-events-none absolute inset-0 flex justify-center">
        <div className="h-96 w-96 rounded-full bg-violet-600/20 blur-[120px]" />
        <div className="absolute top-20 h-80 w-80 rounded-full bg-blue-600/15 blur-[100px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative mx-auto flex max-w-3xl flex-col items-center text-center"
      >
        {/* Logo */}
        <div className="relative mb-6">
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-violet-500 to-blue-500 blur-xl opacity-60" />
          <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-violet-600 via-blue-600 to-cyan-500 text-3xl font-black text-white shadow-2xl">
            AH
          </div>
        </div>

        <h1 className="text-4xl font-black tracking-tight text-white sm:text-5xl">
          CCRAFT <span className="text-gradient">SPACE</span>
        </h1>
        <p className="mt-3 text-lg text-slate-400">
          منصة سكربتات <span className="font-bold text-white">ROBLOX</span> العربية
        </p>

        {/* Quick actions */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/delta"
            className="group flex items-center gap-2 rounded-full border border-yellow-500/30 bg-gradient-to-r from-yellow-500/20 to-amber-500/10 px-6 py-3 text-sm font-bold text-yellow-300 shadow-lg shadow-yellow-900/20 transition hover:scale-105 hover:shadow-yellow-900/40"
          >
            <Zap className="h-4 w-4 fill-yellow-300" />
            <span>عمل مفتاح arab hack</span>
          </Link>

          <Link
            href="/stats"
            className="flex items-center gap-2 rounded-xl btn-gradient px-6 py-3 text-sm font-bold text-white shadow-lg shadow-blue-900/30 transition hover:scale-105 hover:brightness-110"
          >
            <BarChart3 className="h-4 w-4" />
            <span>عرض الإحصائيات المباشرة</span>
          </Link>
        </div>
      </motion.div>
    </section>
  );
}

"use client";

import { Star, Clock, Upload, Smartphone, UserCircle2, Sparkles, ChevronLeft } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function CardsSection() {
  const quickActions = [
    { icon: Upload, label: "انشر سكربت الآن", href: "/upload", color: "text-violet-300" },
    { icon: Smartphone, label: "تصفح تطبيقات APK", href: "/apk", color: "text-blue-300" },
    { icon: UserCircle2, label: "غيّر صورة البروفايل", href: "/profile", color: "text-emerald-300" },
    { icon: Sparkles, label: "اسأل NOVA AI", href: "/nova", color: "text-pink-300" },
  ];

  return (
    <section className="px-4 py-6 pb-24">
      <div className="mx-auto grid max-w-5xl gap-5">
        {/* Featured display cards */}
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative overflow-hidden rounded-3xl border border-violet-500/20 bg-gradient-to-br from-violet-600/25 to-blue-900/20 p-6"
          >
            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-violet-500/20 blur-3xl" />
            <div className="relative flex h-full flex-col justify-between">
              <div>
                <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-yellow-300">
                  <Star className="h-5 w-5 fill-yellow-300" />
                </div>
                <h3 className="text-xl font-black text-white">سكربت اليوم المميز</h3>
                <p className="mt-1 text-sm text-slate-300">
                  Infinite Yield Admin - أداة تحكم متكاملة لكل الألعاب
                </p>
              </div>
              <Link
                href="/scripts/featured"
                className="mt-5 inline-flex w-fit items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-sm font-bold text-white transition hover:bg-white/20"
              >
                عرض السكربت
                <ChevronLeft className="h-4 w-4" />
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative overflow-hidden rounded-3xl border border-violet-500/20 bg-gradient-to-br from-fuchsia-600/25 to-violet-900/20 p-6"
          >
            <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-fuchsia-500/20 blur-3xl" />
            <div className="relative flex h-full flex-col justify-between">
              <div>
                <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-cyan-300">
                  <Clock className="h-5 w-5" />
                </div>
                <h3 className="text-xl font-black text-white">أحدث السكربتات</h3>
                <p className="mt-1 text-sm text-slate-300">
                  اكتشف آخر السكربتات المضافة من المجتمع
                </p>
              </div>
              <div className="mt-5 flex items-center justify-between">
                <span className="text-xs text-slate-400">+24 سكربت هذا الأسبوع</span>
                <Link
                  href="/scripts"
                  className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-sm font-bold text-white transition hover:bg-white/20"
                >
                  عرض الكل
                  <ChevronLeft className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Quick actions vertical list */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5"
        >
          <h3 className="mb-4 text-base font-bold text-white">إجراءات سريعة</h3>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {quickActions.map((action) => (
              <Link
                key={action.label}
                href={action.href}
                className="group flex items-center gap-4 rounded-2xl border border-white/5 bg-white/[0.03] p-4 transition hover:-translate-y-0.5 hover:border-violet-500/30 hover:bg-white/[0.06]"
              >
                <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 ${action.color}`}>
                  <action.icon className="h-5 w-5" />
                </div>
                <span className="text-sm font-bold text-slate-200 group-hover:text-white">
                  {action.label}
                </span>
                <ChevronLeft className="mr-auto h-4 w-4 text-slate-500 group-hover:text-violet-300" />
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

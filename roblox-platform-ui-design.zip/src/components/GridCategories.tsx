"use client";

import {
  FileCode,
  Upload,
  ShieldCheck,
  Users,
  Send,
  MessageSquare,
  Zap,
  BookOpen,
  PlusCircle,
  Code2,
  Key,
  Trophy,
  Award,
  Sparkles,
  UserCircle,
  LogIn,
  BarChart3,
  LifeBuoy,
  Bot,
} from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

function CategoryCard({
  href,
  icon: Icon,
  title,
  subtitle,
  badge,
  gradient = "from-violet-600/20 to-blue-600/10",
  textColor = "text-slate-200",
  iconColor = "text-violet-400",
  colSpan = "",
}: {
  href: string;
  icon: React.ElementType;
  title: string;
  subtitle?: string;
  badge?: string;
  gradient?: string;
  textColor?: string;
  iconColor?: string;
  colSpan?: string;
}) {
  return (
    <Link
      href={href}
      className={`group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br ${gradient} p-4 transition hover:-translate-y-1 hover:border-violet-500/40 hover:shadow-xl hover:shadow-violet-900/20 ${colSpan}`}
    >
      {badge && (
        <span className="absolute left-3 top-3 rounded-md bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
          {badge}
        </span>
      )}
      <div className="flex h-full flex-col items-start justify-between gap-3">
        <div
          className={`flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 ${iconColor}`}
        >
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <h3 className={`text-sm font-bold ${textColor}`}>{title}</h3>
          {subtitle && <p className="mt-0.5 text-[11px] text-slate-500">{subtitle}</p>}
        </div>
      </div>
      <div className="absolute -bottom-4 -right-4 h-20 w-20 rounded-full bg-white/5 blur-xl transition group-hover:bg-white/10" />
    </Link>
  );
}

export default function GridCategories() {
  return (
    <section className="px-4 py-6">
      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-5 md:grid-cols-2">
        {/* الأساسيات */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5"
        >
          <div className="mb-4 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-violet-500" />
            <h2 className="text-base font-bold text-white">الأساسيات</h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <CategoryCard href="/scripts" icon={FileCode} title="السكربتات" subtitle="استعرض" />
            <CategoryCard href="/upload" icon={Upload} title="نشر سكربت" subtitle="شارك" />
            <CategoryCard href="/security" icon={ShieldCheck} title="أمان سكربتات" subtitle="حماية" />
            <CategoryCard href="/community" icon={Users} title="المجتمع" subtitle="تواصل" />
            <CategoryCard href="/telegram" icon={Send} title="تلجرام" subtitle="انضم" />
            <CategoryCard href="/chat" icon={MessageSquare} title="شات" subtitle="تحدث" />
          </div>
        </motion.div>

        {/* الشروحات */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5"
        >
          <div className="mb-4 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-blue-500" />
            <h2 className="text-base font-bold text-white">الشروحات</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <CategoryCard href="/tutorials" icon={BookOpen} title="الشروحات" badge="جديد" />
            <CategoryCard href="/upload-tutorial" icon={PlusCircle} title="نشر شرح" badge="جديد" />
          </div>
        </motion.div>

        {/* أدوات مطورين */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5"
        >
          <div className="mb-4 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-cyan-500" />
            <h2 className="text-base font-bold text-white">أدوات مطورين</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <CategoryCard href="/editor" icon={Code2} title="محرر الأكواد" iconColor="text-cyan-400" />
            <CategoryCard href="/api" icon={Key} title="واجهة API" iconColor="text-cyan-400" />
          </div>
        </motion.div>

        {/* المجتمع */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5"
        >
          <div className="mb-4 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-yellow-500" />
            <h2 className="text-base font-bold text-white">المجتمع</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <CategoryCard href="/leaderboard" icon={Trophy} title="ليدربورد" iconColor="text-yellow-400" />
            <CategoryCard href="/badges" icon={Award} title="بادجات" iconColor="text-yellow-400" />
          </div>
        </motion.div>

        {/* أدوات - NOVA AI */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5 md:col-span-2"
        >
          <div className="mb-4 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-pink-500" />
            <h2 className="text-base font-bold text-white">أدوات</h2>
          </div>
          <Link
            href="/nova"
            className="group relative flex items-center justify-between overflow-hidden rounded-2xl border border-pink-500/20 bg-gradient-to-r from-pink-600/20 via-violet-600/10 to-blue-600/10 p-5 transition hover:-translate-y-1 hover:border-pink-500/40 hover:shadow-xl hover:shadow-pink-900/20"
          >
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-pink-500/20 text-pink-300">
                <Sparkles className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">المساعد الذكي NOVA AI</h3>
                <p className="text-xs text-slate-400">مساعدك في البرمجة والسكربتات</p>
              </div>
            </div>
            <div className="rounded-full bg-white/5 px-3 py-1 text-xs text-slate-300 group-hover:bg-white/10">
              افتح
            </div>
          </Link>
        </motion.div>

        {/* حسابك */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5"
        >
          <div className="mb-4 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-emerald-500" />
            <h2 className="text-base font-bold text-white">حسابك</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <CategoryCard href="/profile" icon={UserCircle} title="بروفايلي" iconColor="text-emerald-400" />
            <CategoryCard href="/login" icon={LogIn} title="تسجيل الدخول" iconColor="text-emerald-400" />
          </div>
        </motion.div>

        {/* معلومات ودعم */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="rounded-3xl border border-white/10 bg-[#13131f]/80 p-5"
        >
          <div className="mb-4 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-orange-500" />
            <h2 className="text-base font-bold text-white">معلومات ودعم</h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <CategoryCard href="/stats" icon={BarChart3} title="إحصائيات" iconColor="text-orange-400" />
            <CategoryCard href="/support" icon={LifeBuoy} title="الدعم" iconColor="text-orange-400" />
            <CategoryCard href="/telegram" icon={Send} title="تلجرام" iconColor="text-orange-400" />
          </div>
        </motion.div>
      </div>

      {/* arab hack big button */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="mx-auto mt-6 max-w-5xl"
      >
        <Link
          href="/delta"
          className="group flex items-center justify-center gap-3 rounded-2xl border border-yellow-500/30 bg-gradient-to-r from-yellow-500/20 via-amber-500/10 to-yellow-500/5 py-4 text-yellow-300 shadow-lg shadow-yellow-900/10 transition hover:-translate-y-1 hover:shadow-yellow-900/30"
        >
          <Zap className="h-5 w-5 fill-yellow-300 transition group-hover:scale-110" />
          <span className="text-base font-bold">arab hack - مفتاح دلتا</span>
        </Link>
      </motion.div>
    </section>
  );
}

"use client";

import { Bell, Link2, Globe, X } from "lucide-react";
import { useState } from "react";
import Link from "next/link";

export default function TopBar() {
  const [lang, setLang] = useState<"AR" | "EN">("AR");
  const [noticeOpen, setNoticeOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        {/* Right side (RTL visual left) */}
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-600 to-blue-600 px-4 py-2 text-sm font-medium text-white shadow-lg shadow-violet-900/30 transition hover:brightness-110">
            <Link2 className="h-4 w-4" />
            <span>اربط حسابك</span>
          </button>

          <button
            onClick={() => setLang((l) => (l === "AR" ? "EN" : "AR"))}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-xs font-semibold text-slate-300 transition hover:bg-white/10"
          >
            {lang}
          </button>

          <button
            onClick={() => setNoticeOpen((v) => !v)}
            className="relative flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-slate-300 transition hover:bg-white/10"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute right-2 top-1 h-2 w-2 rounded-full bg-red-500" />
          </button>
        </div>

        {/* Center */}
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-blue-500 text-sm font-bold text-white">
            AH
          </div>
          <div className="hidden flex-col items-start sm:flex">
            <span className="text-sm font-bold leading-none text-white">عرب هاك</span>
            <span className="text-[10px] text-slate-400">arabhack.space</span>
          </div>
        </Link>
      </div>

      {noticeOpen && (
        <div className="absolute left-4 top-16 z-50 w-72 rounded-2xl border border-white/10 bg-[#13131f] p-4 shadow-2xl">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm font-bold text-white">التنبيهات</span>
            <button onClick={() => setNoticeOpen(false)} className="text-slate-400 hover:text-white">
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="space-y-2">
            <div className="rounded-xl bg-white/5 p-3 text-xs text-slate-300">
              تم إضافة سكربت جديد في قسم السكربتات
            </div>
            <div className="rounded-xl bg-white/5 p-3 text-xs text-slate-300">
              تحديث جديد لواجهة NOVA AI
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

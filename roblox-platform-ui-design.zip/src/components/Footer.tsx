"use client";

import Link from "next/link";
import { X } from "lucide-react";

export default function Footer() {
  const links = [
    { label: "السكربتات", href: "/scripts" },
    { label: "APK Mods", href: "/apk" },
    { label: "الليدربورد", href: "/leaderboard" },
    { label: "الإحصائيات", href: "/stats" },
    { label: "API", href: "/api" },
    { label: "الدعم", href: "/support" },
    { label: "الخصوصية", href: "/privacy" },
  ];

  return (
    <footer className="border-t border-white/10 bg-[#0f0f18] px-4 py-8">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-5">
        <div className="flex flex-wrap items-center justify-center gap-3">
          {links.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs text-slate-400 transition hover:border-violet-500/30 hover:text-white"
            >
              {link.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-violet-600 to-blue-600 text-xs font-bold text-white">
            AH
          </div>
          <span className="text-sm font-bold text-white">عرب هاك</span>
        </div>

        <p className="text-center text-[11px] text-slate-600">
          © 2026 Arab Hack / CCRAFT SPACE. جميع الحقوق محفوظة.
        </p>
      </div>

      <a
        href="https://x.com"
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-4 left-4 z-40 flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-[#13131f] text-slate-300 shadow-lg transition hover:border-violet-500/30 hover:text-white"
      >
        <X className="h-4 w-4" />
      </a>
    </footer>
  );
}
